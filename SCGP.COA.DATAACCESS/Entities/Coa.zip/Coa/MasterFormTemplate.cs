﻿using System;
using System.Collections.Generic;

namespace SCGP.COA.DATAACCESS.Entities.Coa
{
    public partial class MasterFormTemplate
    {
        public int FormTemplateId { get; set; }
        public string FormTemplateName { get; set; } = null!;
    }
}
