﻿using System;
using System.Collections.Generic;

namespace SCGP.COA.DATAACCESS.Entities.Coa
{
    public partial class MasterForm
    {
        public int FormId { get; set; }
        public string FormName { get; set; } = null!;
        public int FormTemplateId { get; set; }
        public int? Property01Id { get; set; }
        public int? Property02Id { get; set; }
        public int? Property03Id { get; set; }
        public int? Property04Id { get; set; }
        public int? Property05Id { get; set; }
        public int? Property06Id { get; set; }
        public int? Property07Id { get; set; }
        public int? Property08Id { get; set; }
        public int? Property09Id { get; set; }
        public int? Property10Id { get; set; }
        public int? Property11Id { get; set; }
        public int? Property12Id { get; set; }
        public int? Property13Id { get; set; }
        public int? Property14Id { get; set; }
        public int? Property15Id { get; set; }
        public int? Property16Id { get; set; }
        public int? Property17Id { get; set; }
        public int? Property18Id { get; set; }
        public int? Property19Id { get; set; }
        public int? Property20Id { get; set; }
    }
}
